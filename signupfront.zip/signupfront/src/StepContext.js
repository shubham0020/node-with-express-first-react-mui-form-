import React, { useState } from 'react';
import App from './App';
export const MultiStepContext = React.createContext();

const StepContext = () => {
    const [currentStep, setStep] = useState(1);
    const [userData,setUserData] = useState([]);
    const [finalData,setFinalData] = useState([]);
    const [errorMessage, setErrorMessage] = React.useState("");

    function submitData(){

      if (userData.firstname.length > 1 && userData.contact.length == 10   && userData.email.length > 1) {
        setFinalData(finalData=>[...finalData, userData]);
        setUserData('');
        
        setStep(1);
      }else{
        setErrorMessage(
          "All * fields are required"
        );
        setStep(1);
      }
      
            
    }

  return (
    <div>
            <MultiStepContext.Provider value={{currentStep,setStep, userData, setUserData, finalData, setFinalData, submitData, errorMessage, setErrorMessage}}>
                <App />
            </MultiStepContext.Provider>
    </div>
  )
}

export default StepContext;