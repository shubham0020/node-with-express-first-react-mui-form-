//const {response} = require('express')
const express = require('express')
const router = express.Router()
const signUpTemplateCopy = require('../models/signUpModels')

router.post('/signup', (req, response) =>{
    Const signedUpUser =  new signUpTemplateCopy({
        fullname:req.body.fullname,
        username:req.body.username,
        email:req.body.email,
        password:req.body.password

    })
    const data = signedUpUser.save()
    return response.status(200).json(data)
        
})


module.exports = router